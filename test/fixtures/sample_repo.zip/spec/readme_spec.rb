

describe 'A Readme file' do
  it 'should exists' do
    File.file?(File.dirname(__FILE__)+'/../README').should be
  end
  
  it 'should fail' do
    false.should be
  end
end

