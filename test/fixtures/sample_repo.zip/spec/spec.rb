require 'rubygems'
require 'spec'

describe 'SampleTest' do
  it "should be true" do
    true.should be
  end
end