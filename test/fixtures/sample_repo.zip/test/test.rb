require 'test_helper'
class SampleTest < ::Test::Unit::TestCase
  def test_true
    assert true
  end
end
