require 'test/unit'
require File.dirname(__FILE__) + '/../lib/my_app'
