$:.unshift File.dirname(__FILE__)

module MyApp
  
end