When 'True' do
  'Not fail'
end